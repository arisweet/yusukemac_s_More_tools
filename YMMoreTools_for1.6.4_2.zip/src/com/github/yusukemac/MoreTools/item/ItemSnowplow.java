package com.github.yusukemac.MoreTools.item;

import com.github.yusukemac.MoreTools.Core;

import net.minecraft.block.Block;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.ItemTool;

public class ItemSnowplow extends ItemTool {
	
	public ItemSnowplow(int par1, EnumToolMaterial par2EnumToolMaterial)
	{
		super(par1, 1.0F, par2EnumToolMaterial, blocksEffectiveAgainst);
		this.setCreativeTab(Core.tabYMTools);
		// TODO 自動生成されたコンストラクター・スタブ
	}
	
	public boolean canHarvestBlock(Block par1Block)
	{
		return par1Block == Block.snow ? true : par1Block == Block.blockSnow;
	}

	public static final Block[] blocksEffectiveAgainst = new Block[] {Block.snow, Block.blockSnow};

}
