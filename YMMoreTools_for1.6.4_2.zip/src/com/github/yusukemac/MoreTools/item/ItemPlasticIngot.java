package com.github.yusukemac.MoreTools.item;

import net.minecraft.item.Item;

public class ItemPlasticIngot extends Item
{

	public ItemPlasticIngot(int par1) {
		super(par1);
	}
	

}
