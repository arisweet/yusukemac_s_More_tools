package com.github.yusukemac.MoreTools.item;

import net.minecraft.block.Block;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.ItemStack;

public class ItemStoneBreaker extends ItemHammer
{
	
	public static final Block[] blocksEffectiveAgainst = new Block[] {Block.stone, Block.cobblestone};
	
	public ItemStoneBreaker(int par1, EnumToolMaterial par2EnumToolMaterial) {
		super(par1, par2EnumToolMaterial);
		// TODO 自動生成されたコンストラクター・スタブ
	}
	
	@Override
	public boolean canHarvestBlock(Block par1Block)
	{
		if (par1Block == Block.stone || par1Block == Block.cobblestone)
			return true;
		return false;
	}
	@Override
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block, int meta)
	{
		return getStrVsBlock(par1ItemStack, par2Block);
	}
	
	@Override
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block)
	{
		for (int i = 0; i < this.blocksEffectiveAgainst.length; i++)
		{
			if (this.blocksEffectiveAgainst[i] == par2Block)
				return this.efficiencyOnProperMaterial;
			else
				return 0;
		}
		return 1.0F;
	}
	

}
