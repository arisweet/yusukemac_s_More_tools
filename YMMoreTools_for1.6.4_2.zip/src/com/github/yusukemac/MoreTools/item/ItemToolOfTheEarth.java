package com.github.yusukemac.MoreTools.item;

import com.github.yusukemac.MoreTools.Core;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemToolOfTheEarth extends ItemToolOfNature
{
	public final Block[] blocksEffectiveAgainst = Block.blocksList;
	
	public float efficiencyOnProperMaterial = 5.0F;
	public static EntityPlayer player;
	private float weaponDamage;
	
	public ItemToolOfTheEarth(int par1, EnumToolMaterial par2EnumToolMaterial) {
		super(par1, par2EnumToolMaterial);
		this.weaponDamage = 5.0F + par2EnumToolMaterial.getDamageVsEntity();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public void onUpdate(ItemStack par1ItemStack, World par2World, Entity par3Entity, int par4, boolean par5)
	{
		if (!par2World.isRemote)
		{
			if (par5)
			{
				player = ((EntityPlayer)par3Entity);	
				player.addPotionEffect(new PotionEffect(Potion.jump.id, 10 * 20, 5));
				player.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 10 * 20, 3));
				player.addPotionEffect(new PotionEffect(Potion.digSpeed.id, 10 * 20, 2));
				player.addPotionEffect(new PotionEffect(Potion.nightVision.id, 10 * 20, 1));
				player.addPotionEffect(new PotionEffect(Potion.resistance.id, 10 * 20, 2));
			}
		}
	}
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block, int meta)
	{
		return this.efficiencyOnProperMaterial;
	}
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block)
	{
		return this.efficiencyOnProperMaterial;
	}
	public boolean canHarvestBlock(Block par1Block)
	{
		return true;
	}

}
