package com.github.yusukemac.MoreTools.item;

import com.github.yusukemac.MoreTools.Core;

import net.minecraft.block.Block;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumToolMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.world.World;

public class ItemSnowplow extends ItemTool {
	
	public ItemSnowplow(int par1, EnumToolMaterial par2EnumToolMaterial)
	{
		super(par1, 1.0F, par2EnumToolMaterial, blocksEffectiveAgainst);
		this.setCreativeTab(Core.tabYMTools);
		this.maxStackSize = 1;
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public boolean onBlockDestroyed(ItemStack par1ItemStack, World par2World, int par3, int par4, int par5, int par6, EntityLivingBase par7EntityLivingBase)
    {
        if ((double)Block.blocksList[par3].getBlockHardness(par2World, par4, par5, par6) != 0.0D)
        {
            par1ItemStack.damageItem(1, par7EntityLivingBase);
        }

        return true;
    }

	public boolean canHarvestBlock(Block par1Block)
	{
		return par1Block == Block.snow ? true : par1Block == Block.blockSnow;
	}
	@Override
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block, int meta)
	{
		return getStrVsBlock(par1ItemStack, par2Block);
	}
	
	@Override
	public float getStrVsBlock(ItemStack par1ItemStack, Block par2Block)
	{
		for (int i = 0; i < this.blocksEffectiveAgainst.length; i++)
		{
			if (this.blocksEffectiveAgainst[i] == par2Block)
				return this.efficiencyOnProperMaterial;
		}
		return 1.0F;
	}

	public static final Block[] blocksEffectiveAgainst = new Block[] {Block.snow, Block.blockSnow};

}
