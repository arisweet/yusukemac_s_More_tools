package com.github.yusukemac.MoreTools.item;

import net.minecraft.item.Item;

public class ItemBase extends Item
{

	public ItemBase(int par1) {
		super(par1);
	}
	

}
